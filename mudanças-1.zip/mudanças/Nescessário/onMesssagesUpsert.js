/**
 * Evento chamado quando uma mensagem
 * é enviada para o grupo do WhatsApp
 *
 * @author Dev Gui
 */
const {
  isAtLeastMinutesInPast,
  GROUP_PARTICIPANT_ADD,
  GROUP_PARTICIPANT_LEAVE,
  isAddOrLeave,
} = require("../utils");
const { dynamicCommand } = require("../utils/dynamicCommand");
const { loadCommonFunctions } = require("../utils/loadCommonFunctions");
const { onGroupParticipantsUpdate } = require("./onGroupParticipantsUpdate");
const { errorLog } = require("../utils/logger");
const { badMacHandler } = require("../utils/badMacHandler");
const { checkMutedUser } = require("../utils/checkMutedUser");

exports.onMessagesUpsert = async ({ socket, messages, groupCache }) => {
  if (!messages.length) {
    return;
  }

  for (const webMessage of messages) {
    try {
      const timestamp = webMessage.messageTimestamp;

      if (isAtLeastMinutesInPast(timestamp)) {
        continue;
      }

      if (isAddOrLeave.includes(webMessage.messageStubType)) {
        let action = "";
        if (webMessage.messageStubType === GROUP_PARTICIPANT_ADD) {
          action = "add";
        } else if (webMessage.messageStubType === GROUP_PARTICIPANT_LEAVE) {
          action = "remove";
        }

        await onGroupParticipantsUpdate({
          userJid: webMessage.messageStubParameters[0],
          remoteJid: webMessage.key.remoteJid,
          socket,
          groupCache,
          action,
        });
      } else {
        const commonFunctions = loadCommonFunctions({ socket, webMessage });

        const wasDeleted = await checkMutedUser({
          socket,
          webMessage,
          developerDebug: process.env.NODE_ENV !== 'production'
        });

        if (wasDeleted) {
          continue;
        }

        if (!commonFunctions) {
          continue;
        }

        await dynamicCommand(commonFunctions);
      }
    } catch (error) {
      if (badMacHandler.handleError(error, "message-processing")) {
        continue;
      }

      if (badMacHandler.isSessionError(error)) {
        errorLog(`Erro de sessão ao processar mensagem: ${error.message}`);
        continue;
      }

      errorLog(`Erro ao processar mensagem: ${error.message}`);

      continue;
    }
  }
};
